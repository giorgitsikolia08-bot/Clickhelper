cmake_minimum_required(VERSION 3.22)

project(clickhelper_alpha VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

set(MOD_ID "clickhelper_alpha" CACHE STRING "LeviLauncher runtime mod id")
set(MOD_NAME "ClickHelper Alpha" CACHE STRING "Display name")
set(MOD_AUTHOR "OpenCode" CACHE STRING "Author field in manifest.json")
set(MOD_VERSION "0.1.0" CACHE STRING "Mod version")
set(MOD_DESCRIPTION
    "Click Repeater and Click Combination for Minecraft Bedrock (technical alpha)"
    CACHE STRING "Description field in manifest.json")
set(MOD_MINECRAFT_VERSIONS "[]" CACHE STRING
    "Raw JSON array for manifest minecraft_versions; empty means all versions")
set(MOD_ICON "" CACHE STRING "Optional package-relative icon path")

# Pinned SDK revision whose public headers define setConfigSchemaJson(),
# ConfigType::Button and the current Mod Menu callbacks.
set(LEVI_SDK_REPOSITORY "https://github.com/LiteLDev/preloader-android.git"
    CACHE STRING "Preloader SDK repository")
set(LEVI_SDK_REVISION
    "cc08b40a31471d3e2dedb267f5f17b28da2b0604"
    CACHE STRING "Pinned preloader-android commit")

option(CLICKHELPER_BUILD_TESTS "Build host-side unit tests" ON)

include(FetchContent)

FetchContent_Declare(
    nlohmann_json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG v3.11.3
)
FetchContent_MakeAvailable(nlohmann_json)

# ---------------------------------------------------------------------------
# Platform-independent modules
# ---------------------------------------------------------------------------

add_library(ch_core STATIC
    src/core/Key.cpp
    src/core/Types.cpp
)
target_include_directories(ch_core PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/include")

add_library(ch_input STATIC src/input/InputState.cpp)
target_link_libraries(ch_input PUBLIC ch_core)

add_library(ch_repeater STATIC src/repeater/RepeaterEngine.cpp)
target_link_libraries(ch_repeater PUBLIC ch_core ch_input)

add_library(ch_combination STATIC src/combination/CombinationEngine.cpp)
target_link_libraries(ch_combination PUBLIC ch_core ch_input)

add_library(ch_settings STATIC src/settings/SettingsStore.cpp)
target_link_libraries(ch_settings PUBLIC ch_core nlohmann_json::nlohmann_json)

add_library(ch_ui STATIC src/ui/MenuModel.cpp)
target_link_libraries(ch_ui PUBLIC ch_core ch_settings nlohmann_json::nlohmann_json)

# ---------------------------------------------------------------------------
# Host verification (no Android SDK / Levi SDK required)
# ---------------------------------------------------------------------------

if(CLICKHELPER_BUILD_TESTS AND NOT ANDROID)
    enable_testing()

    add_executable(ch_tests tests/test_core.cpp)
    target_link_libraries(ch_tests PRIVATE
        ch_core ch_input ch_repeater ch_combination ch_settings ch_ui)
    add_test(NAME clickhelper_core_tests COMMAND ch_tests)

    add_executable(ch_dump_config tools/dump_config.cpp)
    target_link_libraries(ch_dump_config PRIVATE ch_settings ch_ui)
endif()

# ---------------------------------------------------------------------------
# Android native mod
# ---------------------------------------------------------------------------

if(ANDROID)
    if(NOT CMAKE_ANDROID_ARCH_ABI STREQUAL "arm64-v8a")
        message(FATAL_ERROR
            "ClickHelper Alpha targets arm64-v8a only; got "
            "${CMAKE_ANDROID_ARCH_ABI}")
    endif()

    FetchContent_Declare(
        preloader_android
        GIT_REPOSITORY "${LEVI_SDK_REPOSITORY}"
        GIT_TAG "${LEVI_SDK_REVISION}"
    )
    FetchContent_MakeAvailable(preloader_android)

    add_library(ch_platform STATIC src/platform/LeviAdapter.cpp)
    target_include_directories(ch_platform
        PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/include"
        PRIVATE
            "${CMAKE_CURRENT_SOURCE_DIR}/src"
            "${preloader_android_SOURCE_DIR}/include"
    )
    target_link_libraries(ch_platform
        PUBLIC ch_core ch_input ch_repeater ch_combination ch_settings ch_ui
        PRIVATE preloader nlohmann_json::nlohmann_json
    )

    add_library(clickhelper_alpha SHARED src/main.cpp)
    target_include_directories(clickhelper_alpha PRIVATE
        "${CMAKE_CURRENT_SOURCE_DIR}/src"
        "${preloader_android_SOURCE_DIR}/include"
    )
    target_link_libraries(clickhelper_alpha PRIVATE ch_platform)
    set_target_properties(clickhelper_alpha PROPERTIES
        OUTPUT_NAME "clickhelper_alpha"
        PREFIX "lib"
    )
    target_compile_options(clickhelper_alpha PRIVATE
        $<$<COMPILE_LANG_AND_ID:CXX,Clang,GNU>:-fvisibility=hidden -fvisibility-inlines-hidden>
    )
    target_link_options(clickhelper_alpha PRIVATE "-Wl,-z,max-page-size=16384")

    if(NOT CMAKE_STRIP)
        message(FATAL_ERROR "CMAKE_STRIP is required for the native package")
    endif()
    add_custom_command(TARGET clickhelper_alpha POST_BUILD
        COMMAND "${CMAKE_STRIP}" --strip-unneeded
                "$<TARGET_FILE:clickhelper_alpha>"
        COMMENT "Stripping $<TARGET_FILE_NAME:clickhelper_alpha>"
        VERBATIM
    )

    if(MOD_ICON STREQUAL "")
        set(MOD_ICON_JSON "")
    else()
        set(MOD_ICON_JSON "  \"icon\": \"${MOD_ICON}\",")
    endif()

    configure_file(
        "${CMAKE_CURRENT_SOURCE_DIR}/manifest.json.in"
        "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
        @ONLY
    )

    set(LEVI_PACKAGE_ROOT "${CMAKE_CURRENT_BINARY_DIR}/package")
    set(LEVI_PACKAGE_MOD_DIR "${LEVI_PACKAGE_ROOT}/${MOD_ID}")
    set(LEVI_PACKAGE_FILE
        "${CMAKE_CURRENT_BINARY_DIR}/${MOD_ID}-${MOD_VERSION}-${CMAKE_ANDROID_ARCH_ABI}.levipack")

    set(LEVI_ICON_COMMANDS)
    if(NOT MOD_ICON STREQUAL "")
        if(IS_ABSOLUTE "${MOD_ICON}" OR "${MOD_ICON}" MATCHES "(^|/)\\.\\.(/|$)")
            message(FATAL_ERROR "MOD_ICON must be package-relative and contain no ..")
        endif()
        set(LEVI_ICON_SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/${MOD_ICON}")
        if(NOT EXISTS "${LEVI_ICON_SOURCE}")
            message(FATAL_ERROR "MOD_ICON does not exist: ${LEVI_ICON_SOURCE}")
        endif()
        get_filename_component(LEVI_ICON_DIR "${MOD_ICON}" DIRECTORY)
        if(NOT LEVI_ICON_DIR STREQUAL "")
            list(APPEND LEVI_ICON_COMMANDS
                COMMAND "${CMAKE_COMMAND}" -E make_directory
                        "${LEVI_PACKAGE_MOD_DIR}/${LEVI_ICON_DIR}")
        endif()
        list(APPEND LEVI_ICON_COMMANDS
            COMMAND "${CMAKE_COMMAND}" -E copy
                    "${LEVI_ICON_SOURCE}" "${LEVI_PACKAGE_MOD_DIR}/${MOD_ICON}")
    endif()

    add_custom_target(levi_package
        COMMAND "${CMAKE_COMMAND}" -E rm -rf "${LEVI_PACKAGE_ROOT}"
        COMMAND "${CMAKE_COMMAND}" -E make_directory "${LEVI_PACKAGE_MOD_DIR}"
        COMMAND "${CMAKE_COMMAND}" -E copy
                "$<TARGET_FILE:clickhelper_alpha>"
                "${LEVI_PACKAGE_MOD_DIR}/libclickhelper_alpha.so"
        COMMAND "${CMAKE_COMMAND}" -E copy
                "${CMAKE_CURRENT_BINARY_DIR}/manifest.json"
                "${LEVI_PACKAGE_MOD_DIR}/manifest.json"
        ${LEVI_ICON_COMMANDS}
        COMMAND "${CMAKE_COMMAND}" -E copy_directory
                "${CMAKE_CURRENT_SOURCE_DIR}/config"
                "${LEVI_PACKAGE_MOD_DIR}/config"
        COMMAND "${CMAKE_COMMAND}" -E chdir "${LEVI_PACKAGE_ROOT}"
                "${CMAKE_COMMAND}" -E tar "cf" "${LEVI_PACKAGE_FILE}"
                --format=zip "${MOD_ID}"
        DEPENDS clickhelper_alpha
        COMMENT "Packaging ${MOD_ID}-${MOD_VERSION}-${CMAKE_ANDROID_ARCH_ABI}.levipack"
        VERBATIM
    )
endif()
