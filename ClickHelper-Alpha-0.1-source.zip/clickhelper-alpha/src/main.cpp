#include <pl/Mod.hpp>

#include "platform/LeviAdapter.hpp"

PL_REGISTER_MOD(ch::platform::ClickHelperMod,
                ch::platform::ClickHelperMod::instance())
