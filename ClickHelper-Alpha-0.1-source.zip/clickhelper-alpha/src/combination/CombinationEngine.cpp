#include "clickhelper/combination/CombinationEngine.hpp"

#include <algorithm>

namespace ch::combination {

bool CombinationEngine::usable(std::size_t index) const noexcept {
  const auto &profile = mSettings.combinations[index];
  return mSettings.masterEnabled && profile.enabled &&
         profile.actionCount >= core::kCombinationMinActionCount &&
         profile.actionCount <= core::kCombinationMaxActionCount;
}

void CombinationEngine::start(std::size_t index, std::int64_t nowMs) {
  auto &runtime = mRuntime[index];
  runtime.running = true;
  runtime.nextAction = 0;
  runtime.nextActionAt = nowMs;
  mRunning[index] = true;
}

void CombinationEngine::step(std::size_t index, std::int64_t nowMs) {
  const auto &profile = mSettings.combinations[index];
  auto &runtime = mRuntime[index];

  if (runtime.nextAction >= profile.actionCount) {
    runtime.running = false;
    mRunning[index] = false;
    return;
  }

  const auto &action = profile.actions[runtime.nextAction];
  if (core::is_valid(action.key) &&
      action.key.kind != core::KeyKind::None) {
    mSink.tap(action.key);
  }

  ++runtime.nextAction;
  if (runtime.nextAction >= profile.actionCount) {
    runtime.running = false;
    mRunning[index] = false;
    return;
  }

  const int delay = std::clamp(action.delayMs, 0,
                               core::kCombinationMaxDelayMs);
  runtime.nextActionAt = nowMs + delay;
}

void CombinationEngine::run(std::size_t profileIndex, std::int64_t nowMs) {
  if (profileIndex >= core::kProfileCount) return;
  if (!usable(profileIndex)) return;
  if (mRuntime[profileIndex].running) return;
  start(profileIndex, nowMs);
}

void CombinationEngine::update(std::int64_t nowMs) {
  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    if (!usable(i)) {
      mRuntime[i] = {};
      mRunning[i] = false;
      continue;
    }

    const auto &profile = mSettings.combinations[i];
    auto &runtime = mRuntime[i];

    if (!runtime.running) {
      const bool primaryIsSecond =
          profile.trigger2.kind != core::KeyKind::None;
      const core::KeyId primary =
          primaryIsSecond ? profile.trigger2 : profile.trigger1;

      const bool secondaryOk =
          !primaryIsSecond ||
          profile.trigger1.kind == core::KeyKind::None ||
          mState.isDown(profile.trigger1);

      if (primary.kind != core::KeyKind::None && secondaryOk &&
          mState.consumePress(primary)) {
        start(i, nowMs);
      }
    }

    if (runtime.running && nowMs >= runtime.nextActionAt) {
      step(i, nowMs);
    }
  }
}

void CombinationEngine::cancelAll() noexcept {
  for (auto &runtime : mRuntime) {
    runtime = {};
  }
  mRunning.fill(false);
}

} // namespace ch::combination
