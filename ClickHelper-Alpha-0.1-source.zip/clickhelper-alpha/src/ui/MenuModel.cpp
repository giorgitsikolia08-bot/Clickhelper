#include "clickhelper/ui/MenuModel.hpp"

#include <algorithm>

#include <nlohmann/json.hpp>

#include "clickhelper/core/Key.hpp"
#include "clickhelper/settings/SettingsStore.hpp"

namespace ch::ui {

namespace {

using Json = nlohmann::json;

constexpr const char *kCategoryGeneral = "general";
constexpr const char *kCategoryRepeater = "repeater";
constexpr const char *kCategoryCombination = "combination";
constexpr const char *kCategoryDiagnostics = "diagnostics";

const char *type_name(MenuEntryKind kind) {
  switch (kind) {
  case MenuEntryKind::Toggle:
    return "toggle";
  case MenuEntryKind::SliderInt:
    return "slider_int";
  case MenuEntryKind::Choice:
    return "choice";
  case MenuEntryKind::Button:
    return "button";
  case MenuEntryKind::Info:
  default:
    return "info";
  }
}

MenuEntry make_toggle(std::string key, std::string title,
                      std::string category, std::string section,
                      bool defaultValue) {
  return {std::move(key),   std::move(title), std::move(category),
          std::move(section), {}, MenuEntryKind::Toggle,
          defaultValue ? "true" : "false", 0, 0, {}};
}

MenuEntry make_slider(std::string key, std::string title,
                      std::string category, std::string section,
                      int defaultValue, int minValue, int maxValue) {
  return {std::move(key),   std::move(title), std::move(category),
          std::move(section), {}, MenuEntryKind::SliderInt,
          std::to_string(defaultValue), minValue, maxValue, {}};
}

MenuEntry make_choice(std::string key, std::string title,
                      std::string category, std::string section,
                      std::string defaultValue,
                      const std::vector<MenuChoice> &choices) {
  return {std::move(key),   std::move(title), std::move(category),
          std::move(section), {}, MenuEntryKind::Choice,
          std::move(defaultValue), 0, 0, choices};
}

} // namespace

std::vector<MenuChoice> key_choices(bool allowNone) {
  std::vector<MenuChoice> result;
  if (allowNone) {
    result.push_back({"none", "None"});
  }

  // Android KeyEvent codes. These are labels for selection only; delivery to
  // the game is not verified by the public SDK.
  static const std::vector<MenuChoice> keyboard = {
      {"k:4", "Back (4)"},           {"k:19", "D-pad up (19)"},
      {"k:20", "D-pad down (20)"},   {"k:21", "D-pad left (21)"},
      {"k:22", "D-pad right (22)"},  {"k:24", "Volume up (24)"},
      {"k:25", "Volume down (25)"},  {"k:61", "Tab (61)"},
      {"k:62", "Space (62)"},        {"k:66", "Enter (66)"},
      {"k:82", "Menu (82)"},         {"k:96", "Button A (96)"},
      {"k:97", "Button B (97)"},     {"k:111", "Escape (111)"},
      {"k:113", "F1 (113)"},         {"k:114", "F2 (114)"},
  };
  for (const auto &choice : keyboard) result.push_back(choice);

  for (int button = 0; button <= 4; ++button) {
    result.push_back({"m:" + std::to_string(button),
                      "Mouse " + std::to_string(button)});
  }
  return result;
}

std::vector<MenuEntry> build_entries(const core::Settings &settings) {
  std::vector<MenuEntry> entries;

  entries.push_back(make_toggle("masterEnabled", "Master enabled",
                                kCategoryGeneral, "Runtime",
                                settings.masterEnabled));
  entries.push_back(make_toggle("logInputEvents", "Log input events",
                                kCategoryGeneral, "Runtime",
                                settings.logInputEvents));

  const auto withNone = key_choices(true);
  const auto withoutNone = key_choices(false);

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    const auto &profile = settings.repeaters[i];
    const auto section = "Profile " + std::to_string(i + 1);
    entries.push_back(make_toggle(settings::repeater_key(i, "enabled"),
                                  "Enabled", kCategoryRepeater, section,
                                  profile.enabled));
    entries.push_back(make_choice(settings::repeater_key(i, "trigger1"),
                                  "Trigger 1 (optional)", kCategoryRepeater,
                                  section, core::to_string(profile.trigger1),
                                  withNone));
    entries.push_back(make_choice(settings::repeater_key(i, "trigger2"),
                                  "Trigger 2 (required)", kCategoryRepeater,
                                  section, core::to_string(profile.trigger2),
                                  withoutNone));
    entries.push_back(make_choice(settings::repeater_key(i, "target"),
                                  "Repeated key / button", kCategoryRepeater,
                                  section, core::to_string(profile.target),
                                  withoutNone));
    entries.push_back(make_slider(settings::repeater_key(i, "intervalMs"),
                                  "Interval (ms)", kCategoryRepeater, section,
                                  profile.intervalMs,
                                  core::kRepeaterMinIntervalMs,
                                  core::kRepeaterMaxIntervalMs));
  }

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    const auto &profile = settings.combinations[i];
    const auto section = "Profile " + std::to_string(i + 1);
    entries.push_back(make_toggle(settings::combination_key(i, "enabled"),
                                  "Enabled", kCategoryCombination, section,
                                  profile.enabled));
    entries.push_back(make_choice(settings::combination_key(i, "trigger1"),
                                  "Trigger 1 (optional)",
                                  kCategoryCombination, section,
                                  core::to_string(profile.trigger1), withNone));
    entries.push_back(make_choice(settings::combination_key(i, "trigger2"),
                                  "Trigger 2 (optional)",
                                  kCategoryCombination, section,
                                  core::to_string(profile.trigger2), withNone));
    entries.push_back(make_slider(settings::combination_key(i, "actionCount"),
                                  "Action count", kCategoryCombination,
                                  section, profile.actionCount,
                                  core::kCombinationMinActionCount,
                                  core::kCombinationMaxActionCount));

    for (std::size_t a = 0; a < core::kCombinationMaxActionCount; ++a) {
      const auto actionSection =
          section + " / action " + std::to_string(a + 1);
      entries.push_back(make_choice(
          settings::action_key(i, a, "key"), "Key / button",
          kCategoryCombination, actionSection,
          core::to_string(profile.actions[a].key), withNone));
      entries.push_back(make_slider(
          settings::action_key(i, a, "delayMs"), "Delay after action (ms)",
          kCategoryCombination, actionSection, profile.actions[a].delayMs, 0,
          core::kCombinationMaxDelayMs));
    }

    MenuEntry run{settings::combination_key(i, "run"),
                  "Run once (manual)", kCategoryCombination, section,
                  "Starts the sequence immediately; useful when both "
                  "triggers are None.",
                  MenuEntryKind::Button, "true", 0, 0, {}};
    entries.push_back(std::move(run));
  }

  MenuEntry injection{std::string(kCategoryDiagnostics) + ".injection",
                      "Input injection backend",
                      kCategoryDiagnostics,
                      "Status",
                      "The public LeviLauncher SDK exposes input observation "
                      "only. No verified key/mouse injection backend is "
                      "bundled in Alpha 0.1.",
                      MenuEntryKind::Info,
                      {},
                      0,
                      0,
                      {}};
  entries.push_back(std::move(injection));

  MenuEntry version{std::string(kCategoryDiagnostics) + ".version",
                    "Mod version",
                    kCategoryDiagnostics, "Status", "ClickHelper Alpha 0.1",
                    MenuEntryKind::Info, "0.1.0", 0, 0, {}};
  entries.push_back(std::move(version));

  return entries;
}

std::string build_schema_json(const std::vector<MenuEntry> &entries) {
  Json schema = Json::object();
  schema["version"] = 2;
  schema["default_category"] = kCategoryGeneral;
  schema["categories"] = Json::array({
      {{"id", kCategoryGeneral}, {"title", "General"}, {"description", ""}},
      {{"id", kCategoryRepeater},
       {"title", "Click Repeater"},
       {"description", "5 independent profiles"}},
      {{"id", kCategoryCombination},
       {"title", "Click Combination"},
       {"description", "5 independent profiles"}},
      {{"id", kCategoryDiagnostics},
       {"title", "Diagnostics"},
       {"description", "Capability status"}},
  });

  Json nodes = Json::array();
  for (const auto &entry : entries) {
    Json node = Json::object();
    node["id"] = entry.key;
    node["key"] = entry.key;
    node["category"] = entry.category;
    node["title"] = entry.title;
    node["description"] = entry.description;
    node["section"] = entry.section;
    node["type"] = type_name(entry.kind);
    node["style"] = "auto";
    node["default_value"] = entry.defaultValue;
    node["min_value"] = std::to_string(entry.minValue);
    node["max_value"] = std::to_string(entry.maxValue);
    node["step"] = entry.kind == MenuEntryKind::SliderInt ? "1" : "";
    node["unit"] = "";
    node["placeholder"] = "";
    node["action_value"] = "true";
    node["max_length"] = 0;
    node["advanced"] = false;
    node["disabled"] = false;
    node["searchable"] = false;
    node["allow_reorder"] = false;
    node["color_alpha"] = true;
    node["collapsible"] = false;

    Json options = Json::array();
    for (const auto &choice : entry.choices) {
      options.push_back({{"value", choice.value},
                         {"label", choice.label},
                         {"description", ""},
                         {"key", ""},
                         {"disabled", false}});
    }
    node["options"] = std::move(options);
    node["visible_when"] = Json::array();
    node["enabled_when"] = Json::array();
    nodes.push_back(std::move(node));
  }
  schema["nodes"] = std::move(nodes);
  return schema.dump(2);
}

} // namespace ch::ui
