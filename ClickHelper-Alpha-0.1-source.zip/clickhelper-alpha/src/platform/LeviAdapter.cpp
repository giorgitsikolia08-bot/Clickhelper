#include "LeviAdapter.hpp"

#include <chrono>
#include <string_view>

#include <pl/Input.hpp>
#include <pl/ModMenu.hpp>

#include "clickhelper/settings/SettingsStore.hpp"
#include "clickhelper/ui/MenuModel.hpp"

namespace ch::platform {

namespace {

constexpr const char *kModuleId = "clickhelper.main";
constexpr auto kTickPeriod = std::chrono::milliseconds(5);

std::atomic<ClickHelperMod *> gActiveMod{nullptr};
std::atomic_bool gCallbacksRegistered{false};

std::int64_t now_ms() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}

pl::modmenu::ConfigType to_config_type(ui::MenuEntryKind kind) {
  switch (kind) {
  case ui::MenuEntryKind::Toggle:
    return pl::modmenu::ConfigType::Toggle;
  case ui::MenuEntryKind::SliderInt:
    return pl::modmenu::ConfigType::SliderInt;
  case ui::MenuEntryKind::Choice:
    return pl::modmenu::ConfigType::Radio;
  case ui::MenuEntryKind::Button:
    return pl::modmenu::ConfigType::Button;
  case ui::MenuEntryKind::Info:
  default:
    return pl::modmenu::ConfigType::Text;
  }
}

} // namespace

ClickHelperMod &ClickHelperMod::instance() {
  static ClickHelperMod instance;
  return instance;
}

ClickHelperMod::ClickHelperMod()
    : mSelf(*ll::mod::NativeMod::current()),
      mRepeater(mSettings, mRepeaterInput, mSink),
      mCombination(mSettings, mCombinationInput, mSink) {}

bool ClickHelperMod::load() {
  mConfigPath = mSelf.getConfigDir() / "config.json";
  if (!settings::load(mSettings, mConfigPath)) {
    mSelf.getLogger().warn("Config was invalid; using C++ defaults");
    settings::save(mSettings, mConfigPath);
  }
  mSelf.getLogger().info("Loaded {} {}", mSelf.getName(), mSelf.getVersion());
  return true;
}

bool ClickHelperMod::enable() {
  const auto entries = ui::build_entries(mSettings);
  auto builder = pl::modmenu::ModuleBuilder(kModuleId, "ClickHelper Alpha")
                     .modId(mSelf.getId())
                     .description("Click Repeater + Click Combination")
                     .defaultEnabled(true)
                     .hideInHudEditor(true);

  for (const auto &entry : entries) {
    if (entry.kind == ui::MenuEntryKind::Info) continue;
    builder.config(entry.key, entry.title, to_config_type(entry.kind),
                   entry.defaultValue,
                   entry.kind == ui::MenuEntryKind::SliderInt
                       ? std::to_string(entry.minValue)
                       : std::string{},
                   entry.kind == ui::MenuEntryKind::SliderInt
                       ? std::to_string(entry.maxValue)
                       : std::string{});
  }

  builder.onToggle([](std::string_view, bool enabled) {
    // The module toggle is informational; mSettings.masterEnabled is the
    // authoritative runtime switch exposed in the General category.
    (void)enabled;
  });

  builder.onConfigChanged([this](std::string_view moduleId, std::string_view key,
                                 std::string_view value) {
    (void)moduleId;
    const auto outcome = settings::apply_value(
        mSettings, std::string(key), std::string(value));
    if (outcome.runRequested) {
      mCombination.run(outcome.profileIndex, now_ms());
      return;
    }
    if (outcome.updated) {
      settings::save(mSettings, mConfigPath);
    }
  });

  if (!builder.registerModule()) {
    mSelf.getLogger().error("Failed to register Mod Menu module");
    return false;
  }

  if (!pl::modmenu::setConfigSchemaJson(kModuleId,
                                        ui::build_schema_json(entries))) {
    mSelf.getLogger().warn("Mod Menu rejected the v2 settings schema");
  }

  if (!gCallbacksRegistered.exchange(true)) {
    pl::input::registerKeyCallback([](const pl::input::KeyEvent &event) {
      if (auto *mod = gActiveMod.load()) {
        mod->handle_key(event.keyCode, event.isKeyDown);
      }
      // Do not consume: the game must still receive normal input.
      return false;
    });
    pl::input::registerMouseCallback([](const pl::input::MouseEvent &event) {
      if (auto *mod = gActiveMod.load()) {
        mod->handle_mouse(event.button, event.isDown);
      }
      return false;
    });
  }

  gActiveMod.store(this);
  mStop.store(false);
  mTickThread = std::thread([this] { tick_loop(); });

  mSelf.getLogger().warn(
      "Alpha 0.1: no verified key/mouse injection backend is available; "
      "engines observe triggers but simulated taps are not delivered");
  return true;
}

bool ClickHelperMod::disable() {
  mStop.store(true);
  if (mTickThread.joinable()) {
    mTickThread.join();
  }
  gActiveMod.store(nullptr);

  mRepeater.stopAll();
  mCombination.cancelAll();
  mRepeaterInput.reset();
  mCombinationInput.reset();

  pl::modmenu::unregisterModule(kModuleId);
  settings::save(mSettings, mConfigPath);
  return true;
}

bool ClickHelperMod::unload() {
  mSelf.getLogger().info("Unloading ClickHelper Alpha");
  return true;
}

void ClickHelperMod::handle_key(int keyCode, bool down) {
  if (!mSettings.masterEnabled) return;
  if (mSettings.logInputEvents) {
    mSelf.getLogger().debug("key {} down={}", keyCode, down);
  }
  const auto id = core::keyboard(keyCode);
  mRepeaterInput.onEvent(id, down);
  mCombinationInput.onEvent(id, down);
}

void ClickHelperMod::handle_mouse(int button, bool down) {
  if (!mSettings.masterEnabled) return;
  if (mSettings.logInputEvents) {
    mSelf.getLogger().debug("mouse {} down={}", button, down);
  }
  const auto id = core::mouse(button);
  mRepeaterInput.onEvent(id, down);
  mCombinationInput.onEvent(id, down);
}

void ClickHelperMod::tick_loop() {
  while (!mStop.load()) {
    const auto now = now_ms();
    mRepeater.update(now);
    mCombination.update(now);
    std::this_thread::sleep_for(kTickPeriod);
  }
}

} // namespace ch::platform
