#pragma once

#include <atomic>
#include <filesystem>
#include <thread>

#include <pl/Mod.hpp>

#include "clickhelper/combination/CombinationEngine.hpp"
#include "clickhelper/core/IInputSink.hpp"
#include "clickhelper/core/Types.hpp"
#include "clickhelper/input/InputState.hpp"
#include "clickhelper/platform/UnavailableInputSink.hpp"
#include "clickhelper/repeater/RepeaterEngine.hpp"

namespace ch::platform {

/**
 * LeviLauncher lifecycle object. All game-facing SDK calls are confined to
 * this file and LeviAdapter.cpp; core engines stay SDK-independent.
 */
class ClickHelperMod {
public:
  static ClickHelperMod &instance();

  ClickHelperMod();

  bool load();
  bool enable();
  bool disable();
  bool unload();

  [[nodiscard]] ll::mod::NativeMod &self() const noexcept { return mSelf; }

private:
  void tick_loop();
  void handle_key(int keyCode, bool down);
  void handle_mouse(int button, bool down);

  ll::mod::NativeMod &mSelf;
  core::Settings mSettings;
  input::InputState mRepeaterInput;
  input::InputState mCombinationInput;
  UnavailableInputSink mSink;
  repeater::RepeaterEngine mRepeater;
  combination::CombinationEngine mCombination;

  std::filesystem::path mConfigPath;
  std::atomic_bool mStop{true};
  std::thread mTickThread;
};

} // namespace ch::platform
