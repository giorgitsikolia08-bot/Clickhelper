#include "clickhelper/input/InputState.hpp"

namespace ch::input {

std::uint64_t InputState::encode(core::KeyId id) noexcept {
  return (static_cast<std::uint64_t>(id.kind) << 32) |
         static_cast<std::uint32_t>(id.code);
}

void InputState::onEvent(core::KeyId id, bool down) {
  if (!core::is_valid(id)) return;
  const auto key = encode(id);
  std::lock_guard lock(mMutex);
  if (down) {
    if (mDown.insert(key).second) {
      mEdges.insert(key);
    }
  } else {
    mDown.erase(key);
  }
}

bool InputState::isDown(core::KeyId id) const {
  if (!core::is_valid(id)) return false;
  std::lock_guard lock(mMutex);
  return mDown.contains(encode(id));
}

bool InputState::consumePress(core::KeyId id) {
  if (!core::is_valid(id)) return false;
  std::lock_guard lock(mMutex);
  return mEdges.erase(encode(id)) != 0;
}

void InputState::reset() {
  std::lock_guard lock(mMutex);
  mDown.clear();
  mEdges.clear();
}

} // namespace ch::input
