#include "clickhelper/core/Key.hpp"

#include <charconv>
#include <utility>

namespace ch::core {

namespace {

bool parse_number(std::string_view text, int &out) {
  if (text.empty()) return false;
  const char *begin = text.data();
  const char *end = begin + text.size();
  const auto [ptr, ec] = std::from_chars(begin, end, out);
  return ec == std::errc{} && ptr == end;
}

} // namespace

std::string to_string(KeyId id) {
  switch (id.kind) {
  case KeyKind::Keyboard:
    return "k:" + std::to_string(id.code);
  case KeyKind::Mouse:
    return "m:" + std::to_string(id.code);
  case KeyKind::None:
  default:
    return "none";
  }
}

bool parse_key(std::string_view text, KeyId &out) {
  out = {};
  if (text.empty()) return false;

  if (text == "none" || text == "None" || text == "NONE") {
    out = kNoKey;
    return true;
  }

  const auto colon = text.find(':');
  if (colon == std::string_view::npos) return false;

  const auto prefix = text.substr(0, colon);
  int code = 0;
  if (!parse_number(text.substr(colon + 1), code)) return false;

  if (prefix == "k") {
    out = keyboard(code);
  } else if (prefix == "m") {
    out = mouse(code);
  } else {
    return false;
  }
  return is_valid(out);
}

bool is_valid(KeyId id) {
  switch (id.kind) {
  case KeyKind::None:
    return id.code == 0;
  case KeyKind::Keyboard:
    return id.code >= 0 && id.code <= 0xFFFF;
  case KeyKind::Mouse:
    return id.code >= 0 && id.code <= 31;
  default:
    return false;
  }
}

} // namespace ch::core
