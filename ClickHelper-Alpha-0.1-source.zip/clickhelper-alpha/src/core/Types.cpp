#include "clickhelper/core/Types.hpp"

namespace ch::core {

Settings default_settings() {
  Settings settings;
  for (auto &profile : settings.repeaters) {
    profile.enabled = false;
    profile.trigger1 = kNoKey;
    profile.trigger2 = kNoKey;
    profile.target = kNoKey;
    profile.intervalMs = 100;
  }
  for (auto &profile : settings.combinations) {
    profile.enabled = false;
    profile.trigger1 = kNoKey;
    profile.trigger2 = kNoKey;
    profile.actionCount = kCombinationMinActionCount;
    for (auto &action : profile.actions) {
      action.key = kNoKey;
      action.delayMs = 80;
    }
  }
  return settings;
}

} // namespace ch::core
