#include "clickhelper/settings/SettingsStore.hpp"

#include <algorithm>
#include <exception>
#include <fstream>

namespace ch::settings {

namespace {

template <typename T> T value_or(const Json &json, const char *key, T fallback) {
  if (!json.is_object() || !json.contains(key)) return fallback;
  try {
    return json.at(key).get<T>();
  } catch (const std::exception &) {
    return fallback;
  }
}

core::KeyId parse_stored_key(const Json &json, const std::string &key) {
  core::KeyId result{};
  if (json.is_object() && json.contains(key)) {
    try {
      core::parse_key(json.at(key).get<std::string>(), result);
    } catch (const std::exception &) {
      result = {};
    }
  }
  return core::is_valid(result) ? result : core::kNoKey;
}

} // namespace

std::string repeater_key(std::size_t index, std::string_view field) {
  return "repeater.p" + std::to_string(index + 1) + "." +
         std::string(field);
}

std::string combination_key(std::size_t index, std::string_view field) {
  return "combination.c" + std::to_string(index + 1) + "." +
         std::string(field);
}

std::string action_key(std::size_t profile, std::size_t action,
                       std::string_view field) {
  return "combination.c" + std::to_string(profile + 1) + ".action" +
         std::to_string(action + 1) + "." + std::string(field);
}

Json to_json(const core::Settings &settings) {
  Json json = Json::object();
  json["version"] = settings.version;
  json["masterEnabled"] = settings.masterEnabled;
  json["logInputEvents"] = settings.logInputEvents;

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    const auto &profile = settings.repeaters[i];
    json[repeater_key(i, "enabled")] = profile.enabled;
    json[repeater_key(i, "trigger1")] = core::to_string(profile.trigger1);
    json[repeater_key(i, "trigger2")] = core::to_string(profile.trigger2);
    json[repeater_key(i, "target")] = core::to_string(profile.target);
    json[repeater_key(i, "intervalMs")] = profile.intervalMs;
  }

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    const auto &profile = settings.combinations[i];
    json[combination_key(i, "enabled")] = profile.enabled;
    json[combination_key(i, "trigger1")] = core::to_string(profile.trigger1);
    json[combination_key(i, "trigger2")] = core::to_string(profile.trigger2);
    json[combination_key(i, "actionCount")] = profile.actionCount;
    for (std::size_t a = 0; a < core::kCombinationMaxActionCount; ++a) {
      json[action_key(i, a, "key")] = core::to_string(profile.actions[a].key);
      json[action_key(i, a, "delayMs")] = profile.actions[a].delayMs;
    }
  }
  return json;
}

bool from_json(const Json &json, core::Settings &out) {
  if (!json.is_object()) return false;
  out = core::default_settings();
  out.version = value_or<int>(json, "version", out.version);
  out.masterEnabled =
      value_or<bool>(json, "masterEnabled", out.masterEnabled);
  out.logInputEvents =
      value_or<bool>(json, "logInputEvents", out.logInputEvents);

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    auto &profile = out.repeaters[i];
    profile.enabled =
        value_or<bool>(json, repeater_key(i, "enabled").c_str(), false);
    profile.trigger1 = parse_stored_key(json, repeater_key(i, "trigger1"));
    profile.trigger2 = parse_stored_key(json, repeater_key(i, "trigger2"));
    profile.target = parse_stored_key(json, repeater_key(i, "target"));
    profile.intervalMs = std::clamp(
        value_or<int>(json, repeater_key(i, "intervalMs").c_str(), 100),
        core::kRepeaterMinIntervalMs, core::kRepeaterMaxIntervalMs);
  }

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    auto &profile = out.combinations[i];
    profile.enabled =
        value_or<bool>(json, combination_key(i, "enabled").c_str(), false);
    profile.trigger1 = parse_stored_key(json, combination_key(i, "trigger1"));
    profile.trigger2 = parse_stored_key(json, combination_key(i, "trigger2"));
    profile.actionCount = std::clamp(
        value_or<int>(json, combination_key(i, "actionCount").c_str(), 2),
        core::kCombinationMinActionCount,
        core::kCombinationMaxActionCount);
    for (std::size_t a = 0; a < core::kCombinationMaxActionCount; ++a) {
      profile.actions[a].key = parse_stored_key(json, action_key(i, a, "key"));
      profile.actions[a].delayMs = std::clamp(
          value_or<int>(json, action_key(i, a, "delayMs").c_str(), 80), 0,
          core::kCombinationMaxDelayMs);
    }
  }

  return true;
}

namespace {

bool parse_bool(std::string_view text, bool &out) {
  if (text == "true" || text == "1") {
    out = true;
    return true;
  }
  if (text == "false" || text == "0") {
    out = false;
    return true;
  }
  return false;
}

bool parse_int(std::string_view text, int &out) {
  if (text.empty()) return false;
  try {
    out = std::stoi(std::string(text));
    return true;
  } catch (const std::exception &) {
    return false;
  }
}

bool parse_key_value(std::string_view text, core::KeyId &out) {
  return core::parse_key(text, out) && core::is_valid(out);
}

} // namespace

ApplyOutcome apply_value(core::Settings &settings, std::string_view key,
                         std::string_view value) {
  ApplyOutcome outcome;

  if (key == "masterEnabled") {
    outcome.updated = parse_bool(value, settings.masterEnabled);
    return outcome;
  }
  if (key == "logInputEvents") {
    outcome.updated = parse_bool(value, settings.logInputEvents);
    return outcome;
  }

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    auto &repeater = settings.repeaters[i];
    const auto enabledKey = repeater_key(i, "enabled");
    if (key == enabledKey) {
      outcome.updated = parse_bool(value, repeater.enabled);
      return outcome;
    }
    const auto trigger1Key = repeater_key(i, "trigger1");
    if (key == trigger1Key) {
      outcome.updated = parse_key_value(value, repeater.trigger1);
      return outcome;
    }
    const auto trigger2Key = repeater_key(i, "trigger2");
    if (key == trigger2Key) {
      outcome.updated = parse_key_value(value, repeater.trigger2);
      return outcome;
    }
    const auto targetKey = repeater_key(i, "target");
    if (key == targetKey) {
      outcome.updated = parse_key_value(value, repeater.target);
      return outcome;
    }
    const auto intervalKey = repeater_key(i, "intervalMs");
    if (key == intervalKey) {
      int parsed = 0;
      if (parse_int(value, parsed)) {
        repeater.intervalMs = std::clamp(parsed, core::kRepeaterMinIntervalMs,
                                         core::kRepeaterMaxIntervalMs);
        outcome.updated = true;
      }
      return outcome;
    }
  }

  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    auto &combination = settings.combinations[i];
    const auto enabledKey = combination_key(i, "enabled");
    if (key == enabledKey) {
      outcome.updated = parse_bool(value, combination.enabled);
      return outcome;
    }
    const auto trigger1Key = combination_key(i, "trigger1");
    if (key == trigger1Key) {
      outcome.updated = parse_key_value(value, combination.trigger1);
      return outcome;
    }
    const auto trigger2Key = combination_key(i, "trigger2");
    if (key == trigger2Key) {
      outcome.updated = parse_key_value(value, combination.trigger2);
      return outcome;
    }
    const auto countKey = combination_key(i, "actionCount");
    if (key == countKey) {
      int parsed = 0;
      if (parse_int(value, parsed)) {
        combination.actionCount =
            std::clamp(parsed, core::kCombinationMinActionCount,
                       core::kCombinationMaxActionCount);
        outcome.updated = true;
      }
      return outcome;
    }
    const auto runKey = combination_key(i, "run");
    if (key == runKey) {
      outcome.runRequested = true;
      outcome.profileIndex = i;
      return outcome;
    }

    for (std::size_t a = 0; a < core::kCombinationMaxActionCount; ++a) {
      const auto actionKey = action_key(i, a, "key");
      if (key == actionKey) {
        outcome.updated =
            parse_key_value(value, combination.actions[a].key);
        return outcome;
      }
      const auto delayKey = action_key(i, a, "delayMs");
      if (key == delayKey) {
        int parsed = 0;
        if (parse_int(value, parsed)) {
          combination.actions[a].delayMs = std::clamp(
              parsed, 0, core::kCombinationMaxDelayMs);
          outcome.updated = true;
        }
        return outcome;
      }
    }
  }

  return outcome;
}

bool load(core::Settings &out, const std::filesystem::path &path) {
  std::error_code ec;
  if (const auto parent = path.parent_path(); !parent.empty()) {
    std::filesystem::create_directories(parent, ec);
  }

  std::ifstream input(path, std::ios::binary);
  if (!input.is_open()) {
    out = core::default_settings();
    return save(out, path);
  }

  Json json;
  try {
    input >> json;
  } catch (const std::exception &) {
    out = core::default_settings();
    return false;
  }
  return from_json(json, out);
}

bool save(const core::Settings &settings, const std::filesystem::path &path) {
  std::error_code ec;
  if (const auto parent = path.parent_path(); !parent.empty()) {
    std::filesystem::create_directories(parent, ec);
  }
  std::ofstream output(path, std::ios::binary | std::ios::trunc);
  if (!output.is_open()) return false;
  output << to_json(settings).dump(2) << '\n';
  return output.good();
}

} // namespace ch::settings
