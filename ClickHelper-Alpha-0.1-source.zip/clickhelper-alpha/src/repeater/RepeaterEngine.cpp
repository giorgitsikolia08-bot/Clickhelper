#include "clickhelper/repeater/RepeaterEngine.hpp"

#include <algorithm>

namespace ch::repeater {

void RepeaterEngine::update(std::int64_t nowMs) {
  for (std::size_t i = 0; i < core::kProfileCount; ++i) {
    const auto &profile = mSettings.repeaters[i];
    auto &runtime = mRuntime[i];

    const bool usable =
        mSettings.masterEnabled && profile.enabled &&
        core::is_valid(profile.trigger2) &&
        profile.trigger2.kind != core::KeyKind::None &&
        core::is_valid(profile.target) &&
        profile.target.kind != core::KeyKind::None;

    const bool trigger2Down = usable && mState.isDown(profile.trigger2);
    const bool trigger1Ok =
        profile.trigger1.kind == core::KeyKind::None ||
        mState.isDown(profile.trigger1);

    if (!trigger2Down || !trigger1Ok) {
      runtime.active = false;
      mActive[i] = false;
      continue;
    }

    const int interval = std::clamp(profile.intervalMs,
                                    core::kRepeaterMinIntervalMs,
                                    core::kRepeaterMaxIntervalMs);

    if (!runtime.active) {
      runtime.active = true;
      mSink.tap(profile.target);
      // Schedule from the actual update time, not from a stale value.
      runtime.nextTapAt = nowMs + interval;
    } else if (nowMs >= runtime.nextTapAt) {
      mSink.tap(profile.target);
      runtime.nextTapAt = nowMs + interval;
    }

    mActive[i] = runtime.active;
  }
}

void RepeaterEngine::stopAll() noexcept {
  for (auto &runtime : mRuntime) {
    runtime = {};
  }
  mActive.fill(false);
}

} // namespace ch::repeater
