#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

#include <nlohmann/json.hpp>

#include "clickhelper/combination/CombinationEngine.hpp"
#include "clickhelper/core/IInputSink.hpp"
#include "clickhelper/core/Key.hpp"
#include "clickhelper/core/Types.hpp"
#include "clickhelper/input/InputState.hpp"
#include "clickhelper/repeater/RepeaterEngine.hpp"
#include "clickhelper/settings/SettingsStore.hpp"
#include "clickhelper/ui/MenuModel.hpp"

namespace {

int failures = 0;

void check(bool condition, const char *message) {
  if (condition) return;
  ++failures;
  std::cerr << "FAIL: " << message << '\n';
}

void test_key_serialization() {
  using namespace ch::core;
  check(to_string(kNoKey) == "none", "none serializes");
  check(to_string(keyboard(66)) == "k:66", "keyboard serializes");
  check(to_string(mouse(2)) == "m:2", "mouse serializes");

  KeyId parsed{};
  check(parse_key("k:66", parsed) && parsed == keyboard(66), "parse keyboard");
  check(parse_key("m:2", parsed) && parsed == mouse(2), "parse mouse");
  check(parse_key("none", parsed) && parsed == kNoKey, "parse none");
  check(!parse_key("x:1", parsed), "reject unknown prefix");
  check(!parse_key("k:999999", parsed), "reject out-of-range code");
}

void test_defaults() {
  const auto settings = ch::core::default_settings();
  check(settings.repeaters.size() == 5, "five repeater profiles");
  check(settings.combinations.size() == 5, "five combination profiles");
  check(settings.repeaters[0].intervalMs == 100, "default interval");
  check(settings.combinations[0].actionCount == 2, "default action count");
}

void test_repeater_activation() {
  auto settings = ch::core::default_settings();
  auto &profile = settings.repeaters[0];
  profile.enabled = true;
  profile.trigger1 = ch::core::keyboard(19);
  profile.trigger2 = ch::core::keyboard(66);
  profile.target = ch::core::mouse(0);
  profile.intervalMs = 100;

  ch::input::InputState state;
  ch::core::RecordingInputSink sink;
  ch::repeater::RepeaterEngine engine(settings, state, sink);

  state.onEvent(ch::core::keyboard(66), true);
  state.onEvent(ch::core::keyboard(19), true);

  engine.update(1000);
  check(sink.taps().size() == 1, "immediate tap on activation");
  engine.update(1099);
  check(sink.taps().size() == 1, "no tap before interval");
  engine.update(1100);
  check(sink.taps().size() == 2, "tap at interval boundary");

  state.onEvent(ch::core::keyboard(66), false);
  engine.update(5000);
  check(sink.taps().size() == 2, "release stops repetition");
  check(!engine.active()[0], "active flag cleared");
}

void test_repeater_optional_trigger() {
  auto settings = ch::core::default_settings();
  auto &profile = settings.repeaters[1];
  profile.enabled = true;
  profile.trigger1 = ch::core::keyboard(19); // required but not held
  profile.trigger2 = ch::core::keyboard(66);
  profile.target = ch::core::keyboard(62);

  ch::input::InputState state;
  ch::core::RecordingInputSink sink;
  ch::repeater::RepeaterEngine engine(settings, state, sink);

  state.onEvent(ch::core::keyboard(66), true);
  engine.update(1000);
  check(sink.taps().empty(), "missing optional trigger blocks activation");

  state.onEvent(ch::core::keyboard(19), true);
  engine.update(1001);
  check(sink.taps().size() == 1, "activation after both triggers held");
}

void test_combination_one_shot() {
  auto settings = ch::core::default_settings();
  auto &profile = settings.combinations[0];
  profile.enabled = true;
  profile.trigger1 = ch::core::keyboard(19);
  profile.trigger2 = ch::core::keyboard(66);
  profile.actionCount = 3;
  profile.actions[0] = {ch::core::keyboard(62), 50};
  profile.actions[1] = {ch::core::keyboard(61), 100};
  profile.actions[2] = {ch::core::mouse(1), 0};

  ch::input::InputState state;
  ch::core::RecordingInputSink sink;
  ch::combination::CombinationEngine engine(settings, state, sink);

  state.onEvent(ch::core::keyboard(19), true);
  state.onEvent(ch::core::keyboard(66), true);
  engine.update(500);
  check(sink.taps().size() == 1, "first action starts immediately");
  check(sink.taps()[0] == ch::core::keyboard(62), "first action key");

  engine.update(549);
  check(sink.taps().size() == 1, "delay respected");
  engine.update(550);
  check(sink.taps().size() == 2, "second action");
  check(sink.taps()[1] == ch::core::keyboard(61), "second action key");

  engine.update(650);
  check(sink.taps().size() == 3, "third action");
  check(sink.taps()[2] == ch::core::mouse(1), "third action button");

  engine.update(1000);
  check(sink.taps().size() == 3, "held trigger does not restart sequence");
}

void test_combination_manual_run() {
  auto settings = ch::core::default_settings();
  auto &profile = settings.combinations[2];
  profile.enabled = true;
  // Both triggers intentionally None.
  profile.actionCount = 2;
  profile.actions[0] = {ch::core::keyboard(62), 30};
  profile.actions[1] = {ch::core::keyboard(61), 0};

  ch::input::InputState state;
  ch::core::RecordingInputSink sink;
  ch::combination::CombinationEngine engine(settings, state, sink);

  engine.update(100);
  check(sink.taps().empty(), "no automatic trigger when both are None");

  engine.run(2, 200);
  engine.update(200);
  check(sink.taps().size() == 1, "manual run first action");
  engine.update(230);
  check(sink.taps().size() == 2, "manual run second action");
}

void test_settings_roundtrip_and_clamping() {
  const auto path = std::filesystem::temp_directory_path() /
                    "clickhelper_alpha_test_config.json";
  std::filesystem::remove(path);

  auto settings = ch::core::default_settings();
  check(ch::settings::save(settings, path), "save config");

  ch::settings::Json json;
  {
    std::ifstream input(path);
    input >> json;
  }
  json[ch::settings::repeater_key(0, "intervalMs")] = 5000;
  json[ch::settings::combination_key(0, "actionCount")] = 99;
  json[ch::settings::repeater_key(0, "target")] = "k:66";

  ch::core::Settings loaded{};
  check(ch::settings::from_json(json, loaded), "parse config");
  check(loaded.repeaters[0].intervalMs == 1000, "interval clamped to max");
  check(loaded.combinations[0].actionCount == 5, "action count clamped");
  check(loaded.repeaters[0].target == ch::core::keyboard(66),
        "target key restored");

  const auto outcome = ch::settings::apply_value(
      loaded, ch::settings::repeater_key(0, "intervalMs"), "5");
  check(outcome.updated && loaded.repeaters[0].intervalMs == 20,
        "menu value clamped to min");

  const auto run = ch::settings::apply_value(
      loaded, ch::settings::combination_key(0, "run"), "true");
  check(run.runRequested && run.profileIndex == 0, "manual run key routed");

  std::filesystem::remove(path);
}

void test_menu_schema() {
  const auto settings = ch::core::default_settings();
  const auto entries = ch::ui::build_entries(settings);
  check(entries.size() == 2 + 5 * 5 + 5 * 15 + 2,
        "expected number of menu entries");

  const auto parsed = nlohmann::json::parse(
      ch::ui::build_schema_json(entries));
  check(parsed["version"] == 2, "schema version 2");
  check(parsed["categories"].size() == 4, "four categories / tabs");
  check(parsed["nodes"].size() == entries.size(), "all nodes exported");
}

} // namespace

int main() {
  test_key_serialization();
  test_defaults();
  test_repeater_activation();
  test_repeater_optional_trigger();
  test_combination_one_shot();
  test_combination_manual_run();
  test_settings_roundtrip_and_clamping();
  test_menu_schema();

  if (failures == 0) {
    std::cout << "all host tests passed\n";
    return 0;
  }
  std::cerr << failures << " test(s) failed\n";
  return 1;
}
