#pragma once

#include <cstddef>
#include <filesystem>
#include <string>
#include <string_view>

#include <nlohmann/json.hpp>

#include "clickhelper/core/Types.hpp"

namespace ch::settings {

using Json = nlohmann::json;

/** Deterministic flat JSON layout shared with Mod Menu config keys. */
Json to_json(const core::Settings &settings);

/** Tolerates missing fields and clamps every documented range. */
bool from_json(const Json &json, core::Settings &out);

/** Creates the file with defaults when absent. */
bool load(core::Settings &out, const std::filesystem::path &path);

bool save(const core::Settings &settings, const std::filesystem::path &path);

struct ApplyOutcome {
  bool updated{false};
  bool runRequested{false};
  std::size_t profileIndex{0};
};

/** Applies a Mod Menu key/value pair to in-memory settings. */
ApplyOutcome apply_value(core::Settings &settings, std::string_view key,
                         std::string_view value);

/** Returns a stable config key such as "repeater.p1.intervalMs". */
std::string repeater_key(std::size_t index, std::string_view field);
std::string combination_key(std::size_t index, std::string_view field);
std::string action_key(std::size_t profile, std::size_t action,
                       std::string_view field);

} // namespace ch::settings
