#pragma once

#include "clickhelper/core/IInputSink.hpp"

namespace ch::platform {

/**
 * Explicitly inert backend. It reports why no event reached the game instead
 * of pretending that a tap was delivered.
 *
 * Reason: the public LeviLauncher Input API (pl/Input.hpp) only registers
 * observation callbacks. There is no documented function that injects a key
 * or mouse press into Minecraft. Injecting requires game-internal functions
 * that are version-specific and are not part of the SDK contract.
 */
class UnavailableInputSink final : public core::IInputSink {
public:
  core::InjectionResult tap(core::KeyId) override {
    return {false, "no public input injection API in LeviLauncher SDK"};
  }
};

} // namespace ch::platform
