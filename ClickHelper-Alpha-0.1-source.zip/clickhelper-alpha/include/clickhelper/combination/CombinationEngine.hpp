#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

#include "clickhelper/core/IInputSink.hpp"
#include "clickhelper/core/Types.hpp"
#include "clickhelper/input/InputState.hpp"

namespace ch::combination {

/**
 * Click Combination: five independent profiles, one shot per activation.
 *
 * Primary trigger = trigger2 if set, otherwise trigger1. If neither is set the
 * profile has no automatic edge and can only be started via `run()` (menu
 * button / diagnostics).
 *
 * Secondary trigger must be held at the moment of the primary's rising edge.
 * Holding the primary never restarts a finished sequence.
 */
class CombinationEngine {
public:
  CombinationEngine(const core::Settings &settings, input::InputState &state,
                    core::IInputSink &sink) noexcept
      : mSettings(settings), mState(state), mSink(sink) {}

  void update(std::int64_t nowMs);

  /** Manual one-shot trigger, useful for menu buttons and dry runs. */
  void run(std::size_t profileIndex, std::int64_t nowMs);

  void cancelAll() noexcept;

  [[nodiscard]] const std::array<bool, core::kProfileCount> &running() const
      noexcept {
    return mRunning;
  }

private:
  struct Runtime {
    bool running{false};
    int nextAction{0};
    std::int64_t nextActionAt{0};
  };

  bool usable(std::size_t index) const noexcept;
  void start(std::size_t index, std::int64_t nowMs);
  void step(std::size_t index, std::int64_t nowMs);

  const core::Settings &mSettings;
  input::InputState &mState;
  core::IInputSink &mSink;
  std::array<Runtime, core::kProfileCount> mRuntime{};
  std::array<bool, core::kProfileCount> mRunning{};
};

} // namespace ch::combination
