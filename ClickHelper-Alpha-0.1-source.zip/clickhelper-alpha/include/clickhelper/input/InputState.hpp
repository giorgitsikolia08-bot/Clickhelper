#pragma once

#include <cstdint>
#include <mutex>
#include <unordered_set>

#include "clickhelper/core/Key.hpp"

namespace ch::input {

/**
 * Tracks held keys/buttons and rising edges received from the launcher.
 *
 * One instance per engine is intentional: consuming an edge in one engine
 * must not steal it from the other engine.
 */
class InputState {
public:
  void onEvent(core::KeyId id, bool down);

  [[nodiscard]] bool isDown(core::KeyId id) const;

  /** Returns true once for a rising edge, then clears that edge. */
  bool consumePress(core::KeyId id);

  void reset();

private:
  static std::uint64_t encode(core::KeyId id) noexcept;

  mutable std::mutex mMutex;
  std::unordered_set<std::uint64_t> mDown;
  std::unordered_set<std::uint64_t> mEdges;
};

} // namespace ch::input
