#pragma once

#include <vector>

#include "clickhelper/core/Key.hpp"

namespace ch::core {

struct InjectionResult {
  bool delivered{false};
  const char *reason{"not available"};
};

/**
 * Boundary between the platform-independent engines and any real input
 * injection backend. No implementation in this repository claims to deliver
 * events to Minecraft; see README.md ("Known blocker").
 */
class IInputSink {
public:
  virtual ~IInputSink() = default;
  virtual InjectionResult tap(KeyId key) = 0;
};

/** Deterministic sink used by host tests and by dry-run diagnostics. */
class RecordingInputSink final : public IInputSink {
public:
  InjectionResult tap(KeyId key) override {
    mTaps.push_back(key);
    return {true, "recorded"};
  }

  [[nodiscard]] const std::vector<KeyId> &taps() const noexcept {
    return mTaps;
  }

  void clear() noexcept { mTaps.clear(); }

private:
  std::vector<KeyId> mTaps;
};

} // namespace ch::core
