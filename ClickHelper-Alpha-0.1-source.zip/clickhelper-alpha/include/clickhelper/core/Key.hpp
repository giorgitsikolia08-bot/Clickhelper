#pragma once

#include <string>
#include <string_view>

namespace ch::core {

/**
 * Source of an input event / target of a simulated tap.
 *
 * Keyboard codes are Android `android.view.KeyEvent` key codes, because
 * `pl::input::KeyEvent::keyCode` is delivered from the Android view.
 * Mouse button numbers are passed through as reported by
 * `pl::input::MouseEvent::button`; their mapping is not defined by the public
 * SDK and must be verified against a concrete launcher build.
 */
enum class KeyKind : unsigned char {
  None = 0,
  Keyboard = 1,
  Mouse = 2,
};

struct KeyId {
  KeyKind kind{KeyKind::None};
  int code{0};

  friend bool operator==(const KeyId &, const KeyId &) = default;
};

constexpr KeyId kNoKey{};

constexpr KeyId keyboard(int code) { return {KeyKind::Keyboard, code}; }
constexpr KeyId mouse(int button) { return {KeyKind::Mouse, button}; }

/** Serialized form used in config.json: "none", "k:66", "m:0". */
std::string to_string(KeyId id);

bool parse_key(std::string_view text, KeyId &out);

/** Structural validation only; does not prove the game accepts the code. */
bool is_valid(KeyId id);

} // namespace ch::core
