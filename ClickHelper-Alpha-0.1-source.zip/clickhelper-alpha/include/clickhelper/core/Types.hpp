#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

#include "clickhelper/core/Key.hpp"

namespace ch::core {

inline constexpr std::size_t kProfileCount = 5;

inline constexpr int kRepeaterMinIntervalMs = 20;
inline constexpr int kRepeaterMaxIntervalMs = 1000;
inline constexpr int kCombinationMinActionCount = 2;
inline constexpr int kCombinationMaxActionCount = 5;
inline constexpr int kCombinationMaxDelayMs = 1000;

struct CombinationAction {
  KeyId key{};
  /** Delay applied AFTER this action, before the next one. */
  int delayMs{80};
};

struct RepeaterProfile {
  bool enabled{false};
  /** Optional modifier trigger. None means "always satisfied". */
  KeyId trigger1{};
  /** Primary trigger. Must be set for automatic activation. */
  KeyId trigger2{};
  /** Key/button tapped repeatedly. */
  KeyId target{};
  int intervalMs{100};
};

struct CombinationProfile {
  bool enabled{false};
  /** Optional modifier; None is allowed. */
  KeyId trigger1{};
  /** Optional primary trigger; None means no automatic edge (use Run). */
  KeyId trigger2{};
  std::array<CombinationAction, kCombinationMaxActionCount> actions{};
  int actionCount{kCombinationMinActionCount};
};

struct Settings {
  int version{1};
  bool masterEnabled{true};
  bool logInputEvents{false};
  std::array<RepeaterProfile, kProfileCount> repeaters{};
  std::array<CombinationProfile, kProfileCount> combinations{};
};

Settings default_settings();

} // namespace ch::core
