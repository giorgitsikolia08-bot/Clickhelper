#pragma once

#include <string>
#include <vector>

#include "clickhelper/core/Types.hpp"

namespace ch::ui {

/**
 * Platform-neutral description of the menu. The Android adapter translates
 * these entries into `pl::modmenu` calls; visual styling is deliberately not
 * part of this layer and can be replaced independently.
 */
enum class MenuEntryKind {
  Toggle,
  SliderInt,
  Choice,
  Info,
  Button,
};

struct MenuChoice {
  std::string value;
  std::string label;
};

struct MenuEntry {
  std::string key;
  std::string title;
  std::string category;
  std::string section;
  std::string description;
  MenuEntryKind kind{MenuEntryKind::Info};
  std::string defaultValue;
  int minValue{0};
  int maxValue{0};
  std::vector<MenuChoice> choices;
};

std::vector<MenuChoice> key_choices(bool allowNone);

std::vector<MenuEntry> build_entries(const core::Settings &settings);

/** v2 schema consumed by setConfigSchemaJson(); no Levi SDK types leak here. */
std::string build_schema_json(const std::vector<MenuEntry> &entries);

} // namespace ch::ui
