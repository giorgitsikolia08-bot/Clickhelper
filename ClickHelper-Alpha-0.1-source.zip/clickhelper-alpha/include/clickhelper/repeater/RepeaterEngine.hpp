#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

#include "clickhelper/core/IInputSink.hpp"
#include "clickhelper/core/Types.hpp"
#include "clickhelper/input/InputState.hpp"

namespace ch::repeater {

/**
 * Click Repeater: five independent profiles.
 *
 * Activation rule:
 *   master enabled && profile enabled &&
 *   trigger2 down && (trigger1 == None || trigger1 down)
 *
 * While active, `target` is tapped immediately and then every intervalMs.
 * Releasing any required trigger stops the profile.
 */
class RepeaterEngine {
public:
  RepeaterEngine(const core::Settings &settings, input::InputState &state,
                 core::IInputSink &sink) noexcept
      : mSettings(settings), mState(state), mSink(sink) {}

  void update(std::int64_t nowMs);
  void stopAll() noexcept;

  [[nodiscard]] const std::array<bool, core::kProfileCount> &active() const
      noexcept {
    return mActive;
  }

private:
  struct Runtime {
    bool active{false};
    std::int64_t nextTapAt{0};
  };

  const core::Settings &mSettings;
  input::InputState &mState;
  core::IInputSink &mSink;
  std::array<Runtime, core::kProfileCount> mRuntime{};
  std::array<bool, core::kProfileCount> mActive{};
};

} // namespace ch::repeater
