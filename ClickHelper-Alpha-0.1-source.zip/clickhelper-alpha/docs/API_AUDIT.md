# Аудит доступности LeviLauncher API

Дата проверки: 2026-11-24.

## Источники, которые считаются достоверными

1. Официальный курс разработчика Android native mods:
   <https://docs.levimc.org/LeviLaunchroid/guide/developer> (redirect на
   <https://levimc.org/LeviLamina/developer_guides/android/>).
2. Публичный репозиторий SDK `LiteLDev/preloader-android`, зафиксированная
   ревизия `cc08b40a31471d3e2dedb267f5f17b28da2b0604`. Заголовки скачаны
   напрямую и использованы для syntax-only компиляции адаптера.
3. Фактические `.levipack` сторонних модов (`Structura`, `BetterZoom`) из
   локального каталога: `manifest.json` и таблицы динамических символов их
   `.so`. Символы использовались только для подтверждения ABI платформы.
   Исходный код ClickRepeater не использовался ни как основа, ни как зависимость.

## Подтверждено

### Manifest

Реальные манифесты содержат поля:

* `type`: `preload-native`
* `name`, `author`, `description`, `version`
* `entry`: имя `.so`
* необязательные `icon`, `minecraft_versions`, `overwrite_files`,
  `overwrite_folders`

Проект использует ровно этот формат; неизвестные поля не изобретались.

### Точка входа

* В SDK объявлен `PLGetModRegistration` и макрос `PL_REGISTER_MOD(Type, expr)`.
* В реальных `.so` подтверждён экспорт `PLGetModRegistration`.
* Жизненный цикл: `load()` обязателен; `enable()`, `disable()`, `unload()`
  опциональны; объект должен жить весь процесс.
* Контекст: `ll::mod::NativeMod::current()`, каталоги `getConfigDir()` и т.д.

В проекте используется `PL_REGISTER_MOD` в `src/main.cpp`.

### Ввод

`pl/Input.hpp` (ревизия выше) объявляет:

```cpp
struct KeyEvent { int keyCode; unsigned int unicodeChar; bool isKeyDown; };
struct MouseEvent { int button; bool isDown; };
struct TouchEvent { int action; int pointerId; float x; float y; };

void registerKeyCallback(pl::input::KeyCallback);
void registerMouseCallback(pl::input::MouseCallback);
void registerTouchCallback(pl::input::TouchCallback);
void registerTextInputCallback(pl::input::TextInputCallback);
```

Обратные вызовы возвращают `bool` (поглотить событие или нет). Дополнительно
проверен `src/pl/runtime/InputBridge.cpp` той же ревизии: его внутренние
`DispatchKeyEvent` и `DispatchMouse` только рассылают уже полученное событие
зарегистрированным callback-функциям модов и не отправляют его в игру. Удаление
обратного вызова в API **отсутствует** — адаптер регистрирует их один раз и
дальше маршрутизирует через Mod Menu enabled-состояние и указатель активного
мода.

### Меню

`pl/ModMenu.hpp` и `pl/ModMenuConfig.hpp` той же ревизии предоставляют:

* `ModuleBuilder` / `registerModule` / `unregisterModule`;
* типы элементов `Toggle`, `SliderInt`, `Radio`, `Color`, `Keybind`, `Text`,
  `Button`;
* `onConfigChanged(moduleId, key, value)`;
* `setConfigSchemaJson(moduleId, json)` и схему v2 с категориями, секциями,
  условия `visible_when` / `enabled_when`.

Проект строит категории `general`, `repeater`, `combination`, `diagnostics`
как техническую основу будущих вкладок и не задаёт визуальный стиль.

### Хуки и сигнатуры

`pl/memory/Hook.hpp`, `Signature.hpp` предоставляют `hook()`, `unhook()`,
`resolveSignature()`. Это подтверждено и заголовками, и символами в реальных
`.so`. Но это примитивы для работы с адресами конкретного процесса, а не API
отправки ввода.

## Не подтверждено / отсутствует

| Требуется для полной функциональности | Статус |
| --- | --- |
| Публичная функция "нажать клавишу/кнопку" в игре | **Отсутствует** в `pl/Input.hpp` и во всех публичных заголовках SDK |
| Сигнатура/адрес функции обработки ввода для поддерживаемой версии Minecraft | Не определена; в SDK её нет |
| Правила соответствия `MouseEvent::button` кнопкам мыши/пальца | Не описаны в документации |
| Гарантия, что `setConfigSchemaJson` присутствует в инсталлированном у пользователя preloader | Нет; зависит от версии лаунчера |
| Совместимость с конкретным Minecraft-билдом | Не тестировалось на устройстве |

## Следствия

1. Движники repeater/combination детерминированно считают условия и затем
   вызывают `IInputSink::tap()`. В Android-сборке подключён
   `UnavailableInputSink`, который возвращает `delivered = false` с причиной.
   Это сделано специально, чтобы не выдавать неактивный код за работающий.
2. В логе при `enable()` выводится предупреждение об отсутствии бэкенда.
3. Пока бэкенд не реализован и не проверен на устройстве, мод нельзя называть
   рабочим; в README это зафиксировано.

## Проверки, уже выполнены в этой сессии

* Host-сборка: `cmake -S . -B build-host -G Ninja` — успешно.
* Host-тесты: `ctest --test-dir build-host --output-on-failure` — 1/1,
  8 групп проверок (сериализация ключей, дефолты, repeater, optional trigger,
  one-shot combination, manual run, конфиг и климпы, меню-схема).
* Syntax-only компиляция `src/platform/LeviAdapter.cpp` и `src/main.cpp` против
  реальных заголовков SDK ревизии выше — успешно (с минимальными стабами
  `jni.h` / `android/log.h`, так как локально нет NDK).
* Сборка `arm64-v8a` `.so` и импорт в лаунчер **не выполнялись**.
