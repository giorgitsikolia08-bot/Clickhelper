#include <filesystem>
#include <fstream>
#include <iostream>

#include "clickhelper/settings/SettingsStore.hpp"
#include "clickhelper/ui/MenuModel.hpp"

int main(int argc, char **argv) {
  if (argc != 2) {
    std::cerr << "usage: ch_dump_config <output-dir>\n";
    return 2;
  }

  const std::filesystem::path output(argv[1]);
  std::error_code ec;
  std::filesystem::create_directories(output, ec);

  const auto defaults = ch::core::default_settings();
  if (!ch::settings::save(defaults, output / "config.json")) {
    std::cerr << "failed to write config.json\n";
    return 1;
  }

  const auto schema = ch::ui::build_schema_json(ch::ui::build_entries(defaults));
  std::ofstream file(output / "config.schema.json", std::ios::binary);
  if (!file.is_open()) {
    std::cerr << "failed to write config.schema.json\n";
    return 1;
  }
  file << schema << '\n';
  return file.good() ? 0 : 1;
}
