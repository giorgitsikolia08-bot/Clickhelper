#!/usr/bin/env bash
# Reproducible arm64-v8a build for ClickRepeater (LeviLauncher native mod).
#
# Context: the build host is aarch64 Linux. The Android NDK r28c prebuilt clang
# is x86_64-only and cannot run there, so this script uses a native aarch64
# clang-18 with the NDK sysroot. On a normal x86_64 machine just use the NDK
# toolchain directly (see the project's .github/workflows/build.yml).
set -euo pipefail

PROJ_DIR="${PROJ_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"
BUILD_DIR="${BUILD_DIR:-$PROJ_DIR/build-android}"
NDK="${NDK:-/tmp/opencode/ndk_extract/android-ndk-r28c}"
HOST_LLVM="${HOST_LLVM:-/tmp/cx18o/usr/lib/llvm-18}"

export LD_LIBRARY_PATH="$HOST_LLVM/lib:/tmp/cx18o/usr/lib/aarch64-linux-gnu:/tmp/cx18o/usr/lib:/tmp/x2o/usr/lib/aarch64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

cmake -S "$PROJ_DIR" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$PROJ_DIR/build-kit/android-aarch64-toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DFETCHCONTENT_SOURCE_DIR_PRELOADER_ANDROID="${PRELOADER_SRC:-/tmp/opencode/preloader-0.2.2}" \
  -DFETCHCONTENT_SOURCE_DIR_FMT="${FMT_SRC:-/tmp/opencode/deps/fmt}"

cmake --build "$BUILD_DIR" --target levi_package

echo "Package: $BUILD_DIR/ClickRepeater.levipack"
