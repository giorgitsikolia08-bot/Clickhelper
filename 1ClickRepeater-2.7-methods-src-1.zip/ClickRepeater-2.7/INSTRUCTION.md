# Click Repeater 2.6 — исходники и инструкция

## Что это
Мод для LeviLauncher (Android arm64) в формате .levipack.
Держишь кнопку мыши — мод с заданной частотой посылает повторные клики.

Текущая сборка: ClickRepeater-2.6-kbsource.levipack
Исходник: ClickRepeater-2.6-src-1.zip

## Установка
1. В LeviLauncher удали все предыдущие версии Click Repeater.
2. Mods -> Add Mod -> выбери ClickRepeater-2.6-kbsource.levipack.
3. Перезапусти лаунчер.
4. Зайди в мир, зажми ЛКМ или ПКМ.

## Меню
В меню мода две вкладки (два отдельных модуля):
- Click Repeater LMB
- Click Repeater RMB

В каждой вкладке:
- enabled — включение повтора;
- clicks per second — частота 1-30;
- mode 1-4 — None, Ctrl, Shift, Alt;
- button code — 1 = ЛКМ, 2 = ПКМ.

Варианты 5 и 6 с захватом клавиши удалены по просьбе.

## Диагностика
Файл: /sdcard/Download/ClickRepeater-diag.txt
Запасные пути: /storage/emulated/0/Download/..., /data/local/tmp/ClickRepeater-diag.txt.
Перед проверкой удали старый файл.

Строки:
- enable: Click Repeater kbsource — мод загружен;
- worker: started (kbsource) — поток запущен;
- mouse event: button=1/2 down=1/0 — клик дошёл до мода;
- injector: prepared (KeyEvent path) — JNI готов;
- injector: Activity found — Activity найден;
- injector: dispatch key=96/97 exception=0 — клики инъектируются;
- worker: stopped — выключение.

## История правок
1. Оригинал не работал: в .so не было NEEDED libpreloader.so. Добавлено в CMakeLists.txt:
   -L<source>/lib -Wl,--no-as-needed -l:libpreloader-1.5.16.so -Wl,--as-needed
2. Инжектор переписан: шлём KeyEvent 96/97 через Activity.dispatchKeyEvent вместо MotionEvent.
3. Activity ищется через ActivityThread.mActivities.
4. Свои события гасятся через suppressUntilMs = now + 60.
5. Меню: сначала группы, затем два отдельных модуля (вкладки) как на референсе.
6. Варианты 5/6 реализовывались, затем удалены по просьбе.
7. Добавлена файловая диагностика.
8. Последняя сборка kbsource: source KeyEvent = SOURCE_KEYBOARD (0x100) вместо SOURCE_MOUSE (0x2002). Нужна проверка в игре. Если не поможет — вернуть 0x2002 (инъекция там подтверждалась логом).

## Сборка
NDK r28c: /tmp/opencode/ndk_extract/android-ndk-r28c
LLVM 18: /tmp/cx18o/usr/lib/llvm-18/bin
preloader 0.2.2: /tmp/opencode/preloader-0.2.2
fmt: /tmp/opencode/deps/fmt

Команда:
PROJ_DIR=<исходник> BUILD_DIR=<сборка> bash <исходник>/build-kit/build-aarch64.sh

## BetterZoom
Отдельно готов и проверен пользователем: BetterZoom 2.6.
Файлы: BetterZoom-2.6.levipack, BetterZoom-2.6-src-1.zip.
Исходник: /root/chat/work/BetterZoom-src-2.6.

## 2.7-methods (тестовая сборка)
- В каждый модуль (LMB/RMB) добавлен выбор способа отправки клика: `inject method`
  Key (клавиша, источник клавиатура) / KeyMouse (клавиша, источник мышь) / Touch (DOWN/UP мыши) / Full (DOWN → BUTTON_PRESS → BUTTON_RELEASE → UP).
  Переключай в игре и смотри, какой даёт клик. Точка клика — последняя позиция из touch-колбэка, иначе центр экрана.
- Исправлена утечка локальных JNI-ссылок: рабочий поток не возвращается в Java, ссылки копились
  с каждым кликом (лимит ~512 → вылет). Теперь каждый клик в PushLocalFrame/PopLocalFrame.
- В диагностику добавлены handledDown/handledUp (принял ли Activity событие) и номер метода.
